#! /bin/sh

apt-get update
apt-get upgrade

apt-get install -y hydra

cp /vagrant/500-worst-passwords.txt ~/
