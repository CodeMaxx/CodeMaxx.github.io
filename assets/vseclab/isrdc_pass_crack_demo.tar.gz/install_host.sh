#! /bin/sh

apt-get update
apt-get upgrade

sudo apt-get install -y apache2 apache2-doc apache2-utils

cp -r /vagrant/password_crack_demo/website/* /var/www/html
cp /vagrant/password_crack_demo/.htpasswd /etc/apache2/
cp /vagrant/password_crack_demo/apache2.conf /etc/apache2
cp /vagrant/password_crack_demo/.htaccess /var/www/html/account/

service apache2 restart
